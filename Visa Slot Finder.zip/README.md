# Welcome to your Lovable project

This project was built with [Lovable](https://lovable.dev).

## Build with Lovable

Open your project in the [Lovable editor](https://lovable.dev) and keep building.

- **Ship faster**: describe what you want to build and Lovable handles the code.
- **Stay in sync**: connect the project to GitHub and every change made in Lovable is committed straight to your repository.
- **Full ownership**: this code is yours. Push to your repository and your changes sync back into Lovable, ready for your next prompt.

## Development

Prefer working locally? You need Node.js and npm — [install with nvm](https://github.com/nvm-sh/nvm#installing-and-updating).

```sh
git clone <this-repository-url>
cd <repository-name>
npm i
npm run dev
```

## Chrome extension

The unpacked Chrome extension is in the `extension` directory. To install it locally:

1. Open `chrome://extensions` and enable **Developer mode**.
2. Click **Load unpacked**.
3. Select the `extension` directory itself—the folder that directly contains `manifest.json`.

Do not select the repository root (`Visa Slot Finder`) or the ZIP file. Chrome reports
"Manifest file is missing or unreadable" when the selected folder does not directly contain
`manifest.json`.

The extension popup provides two modes: **Full Month** scans every date in the selected month,
while **Specific Date** sends a single check for the selected appointment date.

Keep a logged-in `pk-gr-services.gvcworld.eu` tab open while checking. Version 1.2.0 runs requests
inside that authenticated tab, reads slots from direct or wrapped API responses, and persists the
scan in the background when the popup closes. Requests remain sequential; HTTP 429 responses honor
`Retry-After` and use bounded exponential backoff with jitter before retrying.

## Built with

- TanStack Start
- TypeScript
- React
- Tailwind CSS
