import { createFileRoute } from "@tanstack/react-router";
import { useRef, useState } from "react";

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: "Slot Checker — Visa Slot Checker PK GR Services" },
      {
        name: "description",
        content:
          "Check Greece visa appointment slot availability for a specific date or a full month via PK GR Services.",
      },
      { property: "og:title", content: "Slot Checker — Visa Slot Checker PK GR Services" },
      {
        property: "og:description",
        content:
          "Check Greece visa appointment slot availability for a specific date or a full month via PK GR Services.",
      },
    ],
  }),
  component: SlotChecker,
});

type Result = {
  date: string;
  slotCount: number;
  available: boolean;
  error: string | null;
  status: number | null;
};

type CheckMode = "month" | "date";

const MONTHS = Array.from({ length: 12 }, (_, index) => String(index + 1).padStart(2, "0"));
const YEARS = ["2024", "2025", "2026", "2027", "2028", "2029", "2030"];

function formatSpecificDate(value: string) {
  const match = /^(\d{4})-(\d{2})-(\d{2})$/.exec(value);
  if (!match) return null;

  const [, year, month, day] = match;
  const parsed = new Date(Number(year), Number(month) - 1, Number(day));
  if (
    parsed.getFullYear() !== Number(year) ||
    parsed.getMonth() !== Number(month) - 1 ||
    parsed.getDate() !== Number(day)
  ) {
    return null;
  }

  return `${day}/${month}/${year}`;
}

async function checkSlot(date: string, vacId: number): Promise<Result> {
  try {
    const response = await fetch("/api/check-slot", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ date, vacId }),
    });
    const body = (await response.json()) as Partial<Result> & { error?: string };
    return {
      date,
      slotCount: body.slotCount ?? 0,
      available: body.available ?? false,
      error: body.error ?? null,
      status: body.status ?? null,
    };
  } catch (error) {
    return {
      date,
      slotCount: 0,
      available: false,
      error: `Request failed: ${error instanceof Error ? error.message : String(error)}`,
      status: null,
    };
  }
}

function SlotChecker() {
  const [mode, setMode] = useState<CheckMode>("month");
  const [month, setMonth] = useState("01");
  const [year, setYear] = useState("2026");
  const [specificDate, setSpecificDate] = useState("");
  const [vacId, setVacId] = useState(137);
  const [results, setResults] = useState<Result[]>([]);
  const [loading, setLoading] = useState(false);
  const [progress, setProgress] = useState("");
  const [checked, setChecked] = useState(0);
  const [total, setTotal] = useState(0);
  const cancelledRef = useRef(false);

  const changeMode = (nextMode: CheckMode) => {
    if (loading) return;
    setMode(nextMode);
    setResults([]);
    setProgress("");
    setChecked(0);
    setTotal(0);
  };

  const handleCancel = () => {
    cancelledRef.current = true;
    setProgress("Cancelling…");
  };

  const handleCheck = async () => {
    if (!Number.isInteger(vacId) || vacId <= 0) {
      setProgress("Enter a valid positive VAC ID.");
      return;
    }

    let dates: string[];
    if (mode === "date") {
      const date = formatSpecificDate(specificDate);
      if (!date) {
        setProgress("Choose a valid appointment date.");
        return;
      }
      dates = [date];
    } else {
      const dayCount = new Date(Number(year), Number(month), 0).getDate();
      dates = Array.from({ length: dayCount }, (_, index) => {
        const day = String(index + 1).padStart(2, "0");
        return `${day}/${month}/${year}`;
      });
    }

    cancelledRef.current = false;
    setLoading(true);
    setResults([]);
    setChecked(0);
    setTotal(dates.length);
    const collected: Result[] = [];

    for (let index = 0; index < dates.length; index++) {
      if (cancelledRef.current) {
        setProgress(`Stopped after ${index} of ${dates.length} dates.`);
        break;
      }

      const date = dates[index];
      setProgress(
        mode === "month" ? `Checking ${date} (${index + 1}/${dates.length})…` : `Checking ${date}…`,
      );
      collected.push(await checkSlot(date, vacId));
      setChecked(index + 1);
      setResults([...collected]);

      if (index < dates.length - 1 && !cancelledRef.current) {
        await new Promise((resolve) => setTimeout(resolve, 800));
      }
    }

    if (!cancelledRef.current) setProgress("");
    setLoading(false);
  };

  return (
    <main className="min-h-screen bg-background px-4 py-10">
      <div className="mx-auto w-full max-w-3xl">
        <h1 className="text-3xl font-bold tracking-tight text-foreground">Slot Checker</h1>
        <p className="mt-2 text-sm text-muted-foreground">
          Visa Slot Checker — PK GR Services. Check one appointment date or scan every date in a
          month.
        </p>

        <div className="mt-8 rounded-xl border border-border bg-card p-5">
          <div
            className="grid grid-cols-2 gap-1 rounded-lg bg-muted p-1"
            role="tablist"
            aria-label="Check mode"
          >
            <button
              type="button"
              role="tab"
              aria-selected={mode === "month"}
              onClick={() => changeMode("month")}
              disabled={loading}
              className={`rounded-md px-4 py-2 text-sm font-medium transition-colors disabled:opacity-50 ${
                mode === "month"
                  ? "bg-background text-foreground shadow-sm"
                  : "text-muted-foreground hover:text-foreground"
              }`}
            >
              Full Month
            </button>
            <button
              type="button"
              role="tab"
              aria-selected={mode === "date"}
              onClick={() => changeMode("date")}
              disabled={loading}
              className={`rounded-md px-4 py-2 text-sm font-medium transition-colors disabled:opacity-50 ${
                mode === "date"
                  ? "bg-background text-foreground shadow-sm"
                  : "text-muted-foreground hover:text-foreground"
              }`}
            >
              Specific Date
            </button>
          </div>

          <div
            className={`mt-4 grid gap-4 ${mode === "month" ? "sm:grid-cols-4" : "sm:grid-cols-3"}`}
            role="tabpanel"
          >
            {mode === "month" ? (
              <>
                <label className="flex flex-col gap-1.5 text-sm">
                  <span className="font-medium text-card-foreground">Month</span>
                  <select
                    value={month}
                    onChange={(event) => setMonth(event.target.value)}
                    disabled={loading}
                    className="h-10 rounded-md border border-input bg-background px-3 text-sm text-foreground disabled:opacity-50"
                  >
                    {MONTHS.map((value) => (
                      <option key={value} value={value}>
                        {value}
                      </option>
                    ))}
                  </select>
                </label>

                <label className="flex flex-col gap-1.5 text-sm">
                  <span className="font-medium text-card-foreground">Year</span>
                  <select
                    value={year}
                    onChange={(event) => setYear(event.target.value)}
                    disabled={loading}
                    className="h-10 rounded-md border border-input bg-background px-3 text-sm text-foreground disabled:opacity-50"
                  >
                    {YEARS.map((value) => (
                      <option key={value} value={value}>
                        {value}
                      </option>
                    ))}
                  </select>
                </label>
              </>
            ) : (
              <label className="flex flex-col gap-1.5 text-sm">
                <span className="font-medium text-card-foreground">Appointment date</span>
                <input
                  type="date"
                  value={specificDate}
                  onChange={(event) => setSpecificDate(event.target.value)}
                  disabled={loading}
                  className="h-10 rounded-md border border-input bg-background px-3 text-sm text-foreground disabled:opacity-50"
                />
              </label>
            )}

            <label className="flex flex-col gap-1.5 text-sm">
              <span className="font-medium text-card-foreground">VAC ID</span>
              <input
                type="number"
                min="1"
                value={vacId}
                onChange={(event) => setVacId(Number(event.target.value))}
                disabled={loading}
                className="h-10 rounded-md border border-input bg-background px-3 text-sm text-foreground disabled:opacity-50"
              />
            </label>

            <div className="flex items-end gap-2">
              <button
                type="button"
                onClick={handleCheck}
                disabled={loading}
                className="h-10 flex-1 rounded-md bg-primary px-4 text-sm font-medium text-primary-foreground transition-colors hover:bg-primary/90 disabled:opacity-50"
              >
                {loading ? "Checking…" : mode === "month" ? "Check Month" : "Check Date"}
              </button>
              {loading && mode === "month" && (
                <button
                  type="button"
                  onClick={handleCancel}
                  className="h-10 rounded-md border border-destructive px-4 text-sm font-medium text-destructive transition-colors hover:bg-destructive/10"
                >
                  Cancel
                </button>
              )}
            </div>
          </div>
        </div>

        {(loading || progress) && (
          <div className="mt-4 space-y-2" role="status">
            <div className="flex items-center justify-between text-sm">
              <span className="text-muted-foreground">{progress || "Checking slots…"}</span>
              {loading && (
                <span className="font-medium text-foreground">
                  {checked}/{total}
                </span>
              )}
            </div>
            {loading && (
              <div className="h-2 w-full overflow-hidden rounded-full bg-muted">
                <div
                  className="h-full rounded-full bg-primary transition-all duration-200"
                  style={{ width: `${total > 0 ? (checked / total) * 100 : 0}%` }}
                />
              </div>
            )}
          </div>
        )}

        {results.length > 0 && (
          <div className="mt-6 overflow-hidden rounded-xl border border-border">
            <table className="w-full text-sm">
              <thead className="bg-muted text-muted-foreground">
                <tr>
                  <th className="px-4 py-2.5 text-left font-medium">Date</th>
                  <th className="px-4 py-2.5 text-left font-medium">Slot Count</th>
                  <th className="px-4 py-2.5 text-left font-medium">Status</th>
                </tr>
              </thead>
              <tbody>
                {results.map((result) => (
                  <tr key={result.date} className="border-t border-border bg-card align-top">
                    <td className="px-4 py-2.5 text-card-foreground">{result.date}</td>
                    <td className="px-4 py-2.5 text-card-foreground">
                      {result.error ? "—" : result.slotCount}
                    </td>
                    <td className="px-4 py-2.5">
                      <span
                        className={
                          result.error
                            ? "rounded-full bg-destructive/10 px-2.5 py-1 text-xs font-medium text-destructive"
                            : result.available
                              ? "rounded-full bg-primary/10 px-2.5 py-1 text-xs font-medium text-primary"
                              : "rounded-full bg-muted px-2.5 py-1 text-xs font-medium text-muted-foreground"
                        }
                      >
                        {result.error
                          ? `Error${result.status ? ` ${result.status}` : ""}`
                          : result.available
                            ? "Available"
                            : "Not Available"}
                      </span>
                      {result.error && (
                        <p className="mt-1.5 max-w-md text-xs leading-snug text-destructive">
                          {result.error}
                        </p>
                      )}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </div>
    </main>
  );
}
