import { createFileRoute } from "@tanstack/react-router";
import { z } from "zod";

const schema = z.object({
  date: z.string().regex(/^\d{2}\/\d{2}\/\d{4}$/),
  vacId: z.number().int().positive(),
});

const UPSTREAM = "https://pk-gr-services.gvcworld.eu/api/v1/periodslot/slots";

function json(body: unknown, status = 200) {
  return new Response(JSON.stringify(body), {
    status,
    headers: { "Content-Type": "application/json", "Cache-Control": "no-store" },
  });
}

export const Route = createFileRoute("/api/check-slot")({
  server: {
    handlers: {
      POST: async ({ request }) => {
        let parsed;
        try {
          parsed = schema.parse(await request.json());
        } catch {
          return json(
            { error: "Invalid request body. Expected { date: 'DD/MM/YYYY', vacId: number }" },
            400,
          );
        }

        const payload = {
          datefrom: parsed.date,
          type: 2,
          bookingfor: 0,
          members: 1,
          method: 1,
          travelpurposes: -1,
          howmanyapplicantsareunder12: 0,
          appointmentId: "undefined",
          id: 0,
          vac: { id: parsed.vacId },
        };

        const {
          warmSession,
          storeCookies,
          cookieHeader,
          cookieNames,
          clearSession,
          BROWSER_HEADERS,
        } = await import("@/lib/upstream-session.server");

        const callUpstream = async () => {
          const cookie = cookieHeader();
          const r = await fetch(UPSTREAM, {
            method: "PUT",
            redirect: "follow",
            headers: {
              "Content-Type": "application/json",
              ...BROWSER_HEADERS,
              ...(cookie ? { Cookie: cookie } : {}),
            },
            body: JSON.stringify(payload),
          });
          storeCookies(r);
          return r;
        };

        let res: Response;
        try {
          // Establish/reuse an upstream session (cookies persist between checks).
          await warmSession();
          res = await callUpstream();
          if (res.status === 403) {
            // Session may be stale — re-warm once and retry with fresh cookies.
            clearSession();
            await warmSession(true);
            res = await callUpstream();
          }
        } catch (err) {
          return json(
            {
              date: parsed.date,
              slotCount: 0,
              available: false,
              status: null,
              error: `Network error: ${err instanceof Error ? err.message : String(err)}`,
            },
            502,
          );
        }

        const text = await res.text();
        const sessionCookies = cookieNames();

        if (!res.ok) {
          const blocked = /Incapsula|_Incapsula_Resource/i.test(text);
          const snippet = text
            .replace(/<[^>]*>/g, " ")
            .replace(/\s+/g, " ")
            .trim()
            .slice(0, 160);
          let message: string;
          if (res.status === 403) {
            message = blocked
              ? "HTTP 403 — blocked by the site's bot protection (Incapsula)"
              : "HTTP 403 — access forbidden by the upstream service";
          } else if (res.status === 404) {
            message = "HTTP 404 — endpoint not found upstream";
          } else if (res.status === 429) {
            message = "HTTP 429 — rate limited, slow down and retry later";
          } else {
            message = `HTTP ${res.status}${snippet ? ` — ${snippet}` : ""}`;
          }
          return json(
            {
              date: parsed.date,
              slotCount: 0,
              available: false,
              status: res.status,
              error: message,
              sessionCookies,
            },
            200,
          );
        }

        let data: { slots?: unknown[] } | null = null;
        try {
          data = JSON.parse(text) as { slots?: unknown[] };
        } catch {
          return json(
            {
              date: parsed.date,
              slotCount: 0,
              available: false,
              status: res.status,
              error: `Invalid JSON response — ${text.replace(/\s+/g, " ").trim().slice(0, 160)}`,
            },
            200,
          );
        }

        const slots = Array.isArray(data?.slots) ? data.slots : [];
        return json({
          date: parsed.date,
          slotCount: slots.length,
          available: slots.length > 0,
          status: res.status,
          error: null,
          slots,
          sessionCookies,
        });
      },
    },
  },
});
