import { createFileRoute, Link } from "@tanstack/react-router";

export const Route = createFileRoute("/extension")({
  head: () => ({
    meta: [
      { title: "Chrome Extension — Visa Slot Checker PK GR Services" },
      {
        name: "description",
        content:
          "Download the Visa Slot Checker Chrome extension to scan PK GR Services visa slots from your own logged-in browser session.",
      },
      { property: "og:title", content: "Chrome Extension — Visa Slot Checker PK GR Services" },
      {
        property: "og:description",
        content:
          "Download the Visa Slot Checker Chrome extension to scan PK GR Services visa slots from your own logged-in browser session.",
      },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: ExtensionPage,
});

function download() {
  fetch("/visa-slot-checker-extension.zip")
    .then((res) => {
      if (!res.ok) throw new Error(`Download failed: ${res.status}`);
      return res.blob();
    })
    .then((blob) => {
      const a = document.createElement("a");
      a.href = URL.createObjectURL(blob);
      a.download = "visa-slot-checker-extension.zip";
      a.click();
      URL.revokeObjectURL(a.href);
    })
    .catch((err) => alert(err.message));
}

const STEPS = [
  "Unzip the downloaded file.",
  "Open chrome://extensions in Chrome (or Edge, Brave, Arc, Opera).",
  "Enable Developer mode (toggle in the top-right).",
  "Click Load unpacked and select the folder that directly contains manifest.json (do not select the ZIP or its parent folder).",
  "Open pk-gr-services.gvcworld.eu in a tab and sign in / pass any challenge.",
  "Click the extension icon, choose Full Month or Specific Date, enter the VAC ID, and run the check.",
];

function ExtensionPage() {
  return (
    <main className="min-h-screen bg-background px-4 py-12">
      <div className="mx-auto max-w-2xl">
        <h1 className="text-3xl font-bold tracking-tight text-foreground">
          Visa Slot Checker — Chrome Extension
        </h1>
        <p className="mt-3 text-sm text-muted-foreground">
          The PK GR Services API blocks server-side requests with Incapsula bot protection. This
          extension runs each check inside your logged-in PK GR Services tab, so the request uses
          the same page origin, cookies, and challenge session as the working appointment page.
        </p>

        <button
          onClick={download}
          className="mt-6 inline-flex items-center justify-center rounded-md bg-primary px-5 py-2.5 text-sm font-medium text-primary-foreground transition-colors hover:bg-primary/90"
        >
          Download extension (.zip)
        </button>

        <h2 className="mt-10 text-lg font-semibold text-foreground">Installation</h2>
        <ol className="mt-3 list-decimal space-y-2 pl-5 text-sm text-muted-foreground">
          {STEPS.map((s) => (
            <li key={s}>{s}</li>
          ))}
        </ol>

        <h2 className="mt-10 text-lg font-semibold text-foreground">What it does</h2>
        <ul className="mt-3 list-disc space-y-2 pl-5 text-sm text-muted-foreground">
          <li>Provides Full Month and Specific Date tabs for either type of check.</li>
          <li>Formats selected dates as DD/MM/YYYY for the upstream service.</li>
          <li>
            Sends the official PUT request with <code>credentials: "include"</code> inside the
            authenticated PK GR Services tab.
          </li>
          <li>Runs requests sequentially with spacing, jitter, and automatic 429 backoff.</li>
          <li>Persists progress and results if the popup closes or another tab is opened.</li>
          <li>
            Shows Available (X slots), Not Available, Error 403 / 404 / 429, or Network Error per
            date, with a Cancel button mid-run.
          </li>
        </ul>

        <p className="mt-10 text-sm text-muted-foreground">
          <Link to="/" className="underline underline-offset-4">
            Back to the web slot checker
          </Link>
        </p>
      </div>
    </main>
  );
}
