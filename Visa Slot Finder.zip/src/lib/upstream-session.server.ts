/**
 * In-memory upstream session/cookie jar shared across requests in the same
 * worker isolate. Lets repeated slot checks reuse any cookie (including an
 * Incapsula challenge cookie) established by an earlier request.
 */

const ORIGIN = "https://pk-gr-services.gvcworld.eu";

export const BROWSER_HEADERS: Record<string, string> = {
  Accept: "application/json, text/plain, */*",
  "Accept-Language": "en-US,en;q=0.9",
  Origin: ORIGIN,
  Referer: `${ORIGIN}/`,
  "User-Agent":
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/126.0.0.0 Safari/537.36",
};

type Jar = { cookies: Map<string, string>; warmedAt: number };

const globalRef = globalThis as unknown as { __pkgrJar?: Jar };

function jar(): Jar {
  if (!globalRef.__pkgrJar) {
    globalRef.__pkgrJar = { cookies: new Map<string, string>(), warmedAt: 0 };
  }
  return globalRef.__pkgrJar;
}

/** Parse Set-Cookie header(s) from a response and merge into the jar. */
export function storeCookies(res: Response): void {
  const j = jar();
  const headers = res.headers as unknown as { getSetCookie?: () => string[] };
  const raw: string[] =
    typeof headers.getSetCookie === "function"
      ? headers.getSetCookie()
      : res.headers.get("set-cookie")
        ? [res.headers.get("set-cookie") as string]
        : [];

  for (const line of raw) {
    // A single header value may contain multiple cookies joined by ", " —
    // split only on commas that precede a `name=` pair.
    for (const part of line.split(/,(?=[^;=]+=[^;]*)/)) {
      const pair = part.split(";")[0]?.trim();
      if (!pair) continue;
      const eq = pair.indexOf("=");
      if (eq <= 0) continue;
      const name = pair.slice(0, eq).trim();
      const value = pair.slice(eq + 1).trim();
      if (!name) continue;
      if (value === "" || value === "deleted") j.cookies.delete(name);
      else j.cookies.set(name, value);
    }
  }
}

/** Serialize the jar into a Cookie header value, or undefined when empty. */
export function cookieHeader(): string | undefined {
  const j = jar();
  if (j.cookies.size === 0) return undefined;
  return Array.from(j.cookies.entries())
    .map(([k, v]) => `${k}=${v}`)
    .join("; ");
}

export function cookieNames(): string[] {
  return Array.from(jar().cookies.keys());
}

export function clearSession(): void {
  const j = jar();
  j.cookies.clear();
  j.warmedAt = 0;
}

/**
 * Hit the site root once (at most every 10 minutes) so the upstream can set
 * session / Incapsula cookies before the API call is made.
 */
export async function warmSession(force = false): Promise<void> {
  const j = jar();
  const now = Date.now();
  if (!force && j.cookies.size > 0 && now - j.warmedAt < 10 * 60 * 1000) return;
  try {
    const existing = cookieHeader();
    const res = await fetch(`${ORIGIN}/`, {
      method: "GET",
      redirect: "follow",
      headers: {
        ...BROWSER_HEADERS,
        Accept: "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8",
        ...(existing ? { Cookie: existing } : {}),
      },
    });
    storeCookies(res);
    // Drain the body so the connection can be reused.
    await res.text();
    j.warmedAt = now;
  } catch {
    // Warm-up is best effort; the API call below still runs.
  }
}
