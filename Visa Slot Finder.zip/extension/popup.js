const monthTab = document.getElementById("month-tab");
const dateTab = document.getElementById("date-tab");
const monthPanel = document.getElementById("month-panel");
const datePanel = document.getElementById("date-panel");
const monthEl = document.getElementById("month");
const yearEl = document.getElementById("year");
const specificDateEl = document.getElementById("specific-date");
const vacEl = document.getElementById("vac");
const checkBtn = document.getElementById("check");
const cancelBtn = document.getElementById("cancel");
const statusEl = document.getElementById("status");
const resultsEl = document.getElementById("results");

let mode = "month";
let checking = false;
let currentScanState = null;

for (let month = 1; month <= 12; month++) {
  const value = String(month).padStart(2, "0");
  monthEl.insertAdjacentHTML("beforeend", `<option value="${value}">${value}</option>`);
}

const now = new Date();
const thisYear = now.getFullYear();
const today = `${thisYear}-${String(now.getMonth() + 1).padStart(2, "0")}-${String(now.getDate()).padStart(2, "0")}`;

for (let year = thisYear; year <= thisYear + 4; year++) {
  yearEl.insertAdjacentHTML("beforeend", `<option value="${year}">${year}</option>`);
}

function updateModeUi(nextMode) {
  mode = nextMode === "date" ? "date" : "month";
  const isMonth = mode === "month";
  monthTab.setAttribute("aria-selected", String(isMonth));
  dateTab.setAttribute("aria-selected", String(!isMonth));
  monthPanel.hidden = !isMonth;
  datePanel.hidden = isMonth;
  cancelBtn.hidden = !checking && !isMonth;
  checkBtn.textContent = isMonth ? "Check Month" : "Check Date";
}

function setMode(nextMode) {
  if (checking || (nextMode !== "month" && nextMode !== "date")) return;
  updateModeUi(nextMode);
  chrome.storage.local.set({ mode });
}

monthTab.addEventListener("click", () => setMode("month"));
dateTab.addEventListener("click", () => setMode("date"));

function daysInMonth(month, year) {
  return new Date(Number(year), Number(month), 0).getDate();
}

function formatSpecificDate(value) {
  const match = /^(\d{4})-(\d{2})-(\d{2})$/.exec(value);
  if (!match) return null;

  const [, year, month, day] = match;
  const parsed = new Date(Number(year), Number(month) - 1, Number(day));
  if (
    parsed.getFullYear() !== Number(year) ||
    parsed.getMonth() !== Number(month) - 1 ||
    parsed.getDate() !== Number(day)
  ) {
    return null;
  }

  return `${day}/${month}/${year}`;
}

function selectedDates() {
  if (mode === "date") {
    const date = formatSpecificDate(specificDateEl.value);
    return date ? [date] : [];
  }

  const month = monthEl.value;
  const year = yearEl.value;
  return Array.from({ length: daysInMonth(month, year) }, (_, index) => {
    const day = String(index + 1).padStart(2, "0");
    return `${day}/${month}/${year}`;
  });
}

function formatCheckedAt(value) {
  if (!value) return "";
  const date = new Date(value);
  if (Number.isNaN(date.getTime())) return "";
  return date.toLocaleTimeString([], { hour: "2-digit", minute: "2-digit", second: "2-digit" });
}

function render(results) {
  if (!results.length) {
    resultsEl.innerHTML = "";
    return;
  }

  const rows = results
    .map((result) => {
      const status = typeof result.status === "string" ? result.status : "Network Error";
      const className = result.available
        ? "ok"
        : status.startsWith("Error") || status === "Network Error"
          ? "err"
          : "no";
      const detail = result.error
        ? `<div class="err" style="font-size:11px">${escapeHtml(result.error)}</div>`
        : "";
      const checkedAt = formatCheckedAt(result.checkedAt);
      const responseSource =
        result.source === "api-response"
          ? `<div class="source">API response${result.apiStatus ? ` • HTTP ${escapeHtml(result.apiStatus)}` : ""}${result.apiCode != null ? ` • code ${escapeHtml(result.apiCode)}` : ""}${result.responsePath ? ` • ${escapeHtml(result.responsePath)}` : ""}${checkedAt ? ` • ${escapeHtml(checkedAt)}` : ""}</div>`
          : checkedAt
            ? `<div class="source">Checked ${escapeHtml(checkedAt)}</div>`
            : "";
      return `<tr><td>${escapeHtml(result.date)}</td><td>${result.slotCount == null ? "—" : result.slotCount}</td><td class="${className}">${escapeHtml(status)}${responseSource}${detail}</td></tr>`;
    })
    .join("");

  resultsEl.innerHTML = `<table><thead><tr><th>Date</th><th>Slots</th><th>Status</th></tr></thead><tbody>${rows}</tbody></table>`;
}

function escapeHtml(value) {
  return String(value).replace(
    /[&<>"']/g,
    (character) =>
      ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" })[character],
  );
}

function setChecking(nextChecking) {
  checking = nextChecking;
  checkBtn.disabled = nextChecking;
  monthTab.disabled = nextChecking;
  dateTab.disabled = nextChecking;
  monthEl.disabled = nextChecking;
  yearEl.disabled = nextChecking;
  specificDateEl.disabled = nextChecking;
  vacEl.disabled = nextChecking;
  cancelBtn.disabled = !nextChecking;
  cancelBtn.hidden = !nextChecking && mode === "date";
}

function applySelection(selection) {
  if (!selection) return;
  if (selection.month) monthEl.value = selection.month;
  if (selection.year) yearEl.value = selection.year;
  if (selection.specificDate) specificDateEl.value = selection.specificDate;
}

function applyScanState(state) {
  if (!state) return;
  currentScanState = state;
  updateModeUi(state.mode);
  applySelection(state.selection);
  if (state.vacId) vacEl.value = state.vacId;
  render(Array.isArray(state.results) ? state.results : []);

  const isRunning = state.status === "running";
  setChecking(isRunning);
  statusEl.textContent = state.error
    ? `${state.progress || "Scan error"} ${state.error}`
    : state.progress || "";
}

chrome.storage.local.get(
  ["mode", "month", "year", "specificDate", "vacId", "scanState"],
  (stored) => {
    monthEl.value = stored.month || String(now.getMonth() + 1).padStart(2, "0");
    yearEl.value = stored.year || String(thisYear);
    specificDateEl.value = stored.specificDate || today;
    vacEl.value = stored.vacId || 137;
    updateModeUi(stored.mode === "date" ? "date" : "month");
    if (stored.scanState) {
      applyScanState(stored.scanState);
      if (stored.scanState.status === "running") {
        chrome.runtime.sendMessage({ type: "GET_SCAN_STATE" }).catch(() => {});
      }
    }
  },
);

chrome.storage.onChanged.addListener((changes, areaName) => {
  if (areaName === "local" && changes.scanState?.newValue) {
    applyScanState(changes.scanState.newValue);
  }
});

checkBtn.addEventListener("click", () => {
  const dates = selectedDates();
  const vacId = Number(vacEl.value);

  if (!Number.isInteger(vacId) || vacId <= 0) {
    statusEl.textContent = "Enter a valid positive VAC ID.";
    return;
  }
  if (!dates.length) {
    statusEl.textContent = "Choose a valid appointment date.";
    return;
  }

  const selection = {
    month: monthEl.value,
    year: yearEl.value,
    specificDate: specificDateEl.value,
  };
  chrome.storage.local.set({ mode, ...selection, vacId });
  statusEl.textContent = "Starting background scan…";
  render([]);
  setChecking(true);

  chrome.runtime.sendMessage({ type: "START_SCAN", mode, dates, vacId, selection }, (response) => {
    if (chrome.runtime.lastError) {
      setChecking(false);
      statusEl.textContent = chrome.runtime.lastError.message;
    } else if (!response?.ok) {
      if (response?.state) applyScanState(response.state);
      else setChecking(false);
      statusEl.textContent = response?.error || "Unable to start the scan.";
    } else if (response.state) {
      applyScanState(response.state);
    }
  });
});

cancelBtn.addEventListener("click", () => {
  if (!currentScanState || currentScanState.status !== "running") return;
  cancelBtn.disabled = true;
  statusEl.textContent = "Cancelling…";
  chrome.runtime.sendMessage({ type: "CANCEL_SCAN" }, (response) => {
    if (chrome.runtime.lastError) {
      statusEl.textContent = chrome.runtime.lastError.message;
      cancelBtn.disabled = false;
    } else if (response?.state) {
      applyScanState(response.state);
    }
  });
});
