const API_URL = "https://pk-gr-services.gvcworld.eu/api/v1/periodslot/slots";
const ORIGIN = "https://pk-gr-services.gvcworld.eu";
const SCAN_STATE_KEY = "scanState";
const WATCHDOG_ALARM = "visa-slot-scan-watchdog";
const REQUEST_DELAY_MS = 2500;
const REQUEST_JITTER_MS = 1000;
const MAX_429_RETRIES = 3;
const RETRY_BASE_MS = 10000;
const RETRY_MAX_MS = 60000;

let activeScanPromise = null;

class ScanCancelledError extends Error {}

function buildPayload(date, vacId) {
  return {
    datefrom: date,
    type: 2,
    bookingfor: 0,
    members: 1,
    method: 1,
    travelpurposes: -1,
    howmanyapplicantsareunder12: 0,
    appointmentId: "undefined",
    id: 0,
    vac: { id: Number(vacId) },
  };
}

async function requestFromAuthenticatedPage(apiUrl, expectedOrigin, payload) {
  if (window.location.origin !== expectedOrigin) {
    return { error: `Unexpected page origin: ${window.location.origin}` };
  }

  try {
    const response = await window.fetch(apiUrl, {
      method: "PUT",
      credentials: "include",
      headers: {
        "Content-Type": "application/json",
        Accept: "application/json, text/plain, */*",
      },
      body: JSON.stringify(payload),
    });

    return {
      ok: response.ok,
      status: response.status,
      retryAfter: response.headers.get("Retry-After"),
      text: await response.text(),
    };
  } catch (error) {
    return {
      error: error instanceof Error ? error.message : String(error),
    };
  }
}

async function findAuthenticatedTab() {
  const tabs = await chrome.tabs.query({ url: `${ORIGIN}/*` });
  const tab = tabs.find((candidate) => candidate.active) || tabs[0];

  if (!tab || typeof tab.id !== "number") {
    throw new Error(
      "Open pk-gr-services.gvcworld.eu in a tab, sign in, pass any challenge, and retry.",
    );
  }

  return tab;
}

async function requestSlotData(payload) {
  const tab = await findAuthenticatedTab();
  const injectionResults = await chrome.scripting.executeScript({
    target: { tabId: tab.id },
    world: "MAIN",
    func: requestFromAuthenticatedPage,
    args: [API_URL, ORIGIN, payload],
  });
  const pageResponse = injectionResults[0]?.result;

  if (!pageResponse) {
    throw new Error("The authenticated page did not return an API response.");
  }
  if (pageResponse.error) {
    throw new Error(`Authenticated page request failed: ${pageResponse.error}`);
  }

  return pageResponse;
}

function parseNestedJson(value) {
  let parsed = value;
  for (let depth = 0; depth < 4 && typeof parsed === "string"; depth++) {
    parsed = JSON.parse(parsed);
  }
  return parsed;
}

function extractSlots(value, depth = 0, path = "response") {
  if (depth > 5) return { found: false };

  let current;
  try {
    current = parseNestedJson(value);
  } catch {
    return { found: false };
  }

  if (Array.isArray(current)) return { found: true, slots: current, path };
  if (!current || typeof current !== "object") return { found: false };

  if ("slots" in current) {
    if (current.slots === null) return { found: true, slots: [], path: `${path}.slots` };

    let slots;
    try {
      slots = parseNestedJson(current.slots);
    } catch {
      return { found: true, invalid: true };
    }
    return Array.isArray(slots)
      ? { found: true, slots, path: `${path}.slots` }
      : { found: true, invalid: true };
  }

  const wrapperFields = [
    "returnobject",
    "returnObject",
    "return_object",
    "data",
    "result",
    "payload",
    "response",
  ];
  for (const field of wrapperFields) {
    if (field in current) {
      const extracted = extractSlots(current[field], depth + 1, `${path}.${field}`);
      if (extracted.found) return extracted;
    }
  }

  return { found: false };
}

function parseRetryAfter(value) {
  if (!value) return null;
  const seconds = Number(value);
  if (Number.isFinite(seconds) && seconds >= 0) return Math.ceil(seconds * 1000);

  const retryDate = Date.parse(value);
  if (Number.isNaN(retryDate)) return null;
  return Math.max(0, retryDate - Date.now());
}

async function checkSlot(date, vacId) {
  try {
    const response = await requestSlotData(buildPayload(date, vacId));
    const responseMetadata = {
      source: "api-response",
      apiStatus: response.status,
      checkedAt: new Date().toISOString(),
    };

    if (response.status === 403) {
      return {
        date,
        status: "Error 403",
        slotCount: null,
        ...responseMetadata,
        error:
          "Blocked by the site. Refresh the PK GR Services tab, pass the Incapsula challenge, and retry.",
      };
    }
    if (response.status === 404) {
      return {
        date,
        status: "Error 404",
        slotCount: null,
        ...responseMetadata,
        error: "Endpoint not found.",
      };
    }
    if (response.status === 429) {
      return {
        date,
        status: "Error 429",
        slotCount: null,
        ...responseMetadata,
        retryable: true,
        rateLimited: true,
        retryAfter: response.retryAfter || null,
        retryAfterMs: parseRetryAfter(response.retryAfter),
        error: "Rate limited — waiting before retrying.",
      };
    }
    if (!response.ok) {
      return {
        date,
        status: `Error ${response.status}`,
        slotCount: null,
        ...responseMetadata,
        error: response.text.slice(0, 200),
      };
    }

    let data;
    try {
      data = parseNestedJson(response.text);
    } catch {
      return {
        date,
        status: "Network Error",
        slotCount: null,
        ...responseMetadata,
        error: `Non-JSON response: ${response.text.slice(0, 120)}`,
      };
    }

    const apiCode =
      data &&
      typeof data === "object" &&
      (typeof data.code === "string" || typeof data.code === "number")
        ? data.code
        : null;
    if (Number(apiCode) === 429) {
      return {
        date,
        status: "Error 429",
        slotCount: null,
        ...responseMetadata,
        apiCode,
        retryable: true,
        rateLimited: true,
        retryAfter: response.retryAfter || null,
        retryAfterMs: parseRetryAfter(response.retryAfter),
        error:
          typeof data.message === "string"
            ? data.message.slice(0, 160)
            : "Rate limited — waiting before retrying.",
      };
    }

    const extracted = extractSlots(data);
    if (!extracted.found) {
      const keys = data && typeof data === "object" ? Object.keys(data).join(", ") : "none";
      const message =
        data && typeof data === "object" && typeof data.message === "string"
          ? ` Message: ${data.message.slice(0, 120)}`
          : "";
      return {
        date,
        status: "Network Error",
        slotCount: null,
        ...responseMetadata,
        error: `Unexpected API response: slots field is missing (fields: ${keys || "none"}).${message}`,
      };
    }
    if (extracted.invalid) {
      return {
        date,
        status: "Network Error",
        slotCount: null,
        ...responseMetadata,
        error: "Unexpected API response: slots field is not an array.",
      };
    }

    const slots = extracted.slots;
    return {
      date,
      slotCount: slots.length,
      status: slots.length > 0 ? `Available (${slots.length} slots)` : "Not Available",
      available: slots.length > 0,
      ...responseMetadata,
      apiCode,
      responsePath: extracted.path,
    };
  } catch (error) {
    const message = error instanceof Error ? error.message : String(error);
    const siteAccessHint =
      /Cannot access|permission|The extensions gallery cannot be scripted/i.test(message)
        ? " Set the extension's Site access to pk-gr-services.gvcworld.eu and refresh that tab."
        : "";
    return {
      date,
      status: "Network Error",
      slotCount: null,
      error: `${message}${siteAccessHint}`,
      checkedAt: new Date().toISOString(),
    };
  }
}

function createRunId() {
  return globalThis.crypto?.randomUUID?.() || `${Date.now()}-${Math.random()}`;
}

function isValidDate(value) {
  return /^\d{2}\/\d{2}\/\d{4}$/.test(value);
}

function isRunnableScanState(state) {
  return (
    state?.status === "running" &&
    typeof state.runId === "string" &&
    Array.isArray(state.dates) &&
    state.dates.length > 0 &&
    Number.isInteger(state.nextIndex)
  );
}

async function getScanState() {
  return (await chrome.storage.local.get(SCAN_STATE_KEY))[SCAN_STATE_KEY] || null;
}

function scheduleWatchdog() {
  chrome.alarms.create(WATCHDOG_ALARM, { delayInMinutes: 0.5 });
}

async function updateBadge(state) {
  if (state.status === "running") {
    await chrome.action.setBadgeBackgroundColor({ color: "#2563eb" });
    await chrome.action.setBadgeText({ text: `${state.checked}/${state.total}` });
  } else if (state.status === "completed") {
    await chrome.action.setBadgeBackgroundColor({ color: "#047857" });
    await chrome.action.setBadgeText({ text: "✓" });
  } else if (state.status === "error") {
    await chrome.action.setBadgeBackgroundColor({ color: "#b91c1c" });
    await chrome.action.setBadgeText({ text: "!" });
  } else {
    await chrome.action.setBadgeText({ text: "" });
  }
}

async function saveScanState(state) {
  const nextState = { ...state, updatedAt: new Date().toISOString() };
  await chrome.storage.local.set({ [SCAN_STATE_KEY]: nextState });
  await updateBadge(nextState);
  if (nextState.status === "running") scheduleWatchdog();
  else await chrome.alarms.clear(WATCHDOG_ALARM);
  return nextState;
}

async function assertScanActive(runId) {
  const state = await getScanState();
  if (!state || state.runId !== runId || state.status !== "running" || state.cancelRequested) {
    throw new ScanCancelledError("Scan cancelled");
  }
  return state;
}

async function waitWithPersistence(runId, delayMs) {
  let remaining = Math.max(0, delayMs);
  while (remaining > 0) {
    const chunk = Math.min(5000, remaining);
    await new Promise((resolve) => setTimeout(resolve, chunk));
    remaining -= chunk;
    await assertScanActive(runId);
  }
}

function retryDelay(result, retryNumber) {
  const exponential = Math.min(RETRY_BASE_MS * 2 ** (retryNumber - 1), RETRY_MAX_MS);
  const withJitter = exponential + Math.floor(Math.random() * 2000);
  return Math.max(withJitter, result.retryAfterMs || 0);
}

async function checkDateWithRetries(runId, date, vacId) {
  for (let attempt = 0; attempt <= MAX_429_RETRIES; attempt++) {
    await assertScanActive(runId);
    const result = await checkSlot(date, vacId);
    if (!result.rateLimited || attempt === MAX_429_RETRIES) {
      if (result.rateLimited) {
        result.error = `Rate limited after ${MAX_429_RETRIES} retries. Try again later.`;
      }
      return result;
    }

    const retryNumber = attempt + 1;
    const delayMs = retryDelay(result, retryNumber);
    const state = await assertScanActive(runId);
    await saveScanState({
      ...state,
      progress: `Rate limited on ${date}. Retrying in ${Math.ceil(delayMs / 1000)}s (${retryNumber}/${MAX_429_RETRIES})…`,
      retry: { date, attempt: retryNumber, delayMs, retryAfter: result.retryAfter || null },
    });
    await waitWithPersistence(runId, delayMs);
  }
}

async function finishCancelledScan(runId) {
  const state = await getScanState();
  if (!state || state.runId !== runId) return;
  await saveScanState({
    ...state,
    status: "cancelled",
    cancelRequested: false,
    retry: null,
    progress: `Cancelled — ${state.checked}/${state.total} dates checked.`,
    finishedAt: new Date().toISOString(),
  });
}

async function runPersistedScan() {
  const initialState = await getScanState();
  if (!isRunnableScanState(initialState)) return;
  const runId = initialState.runId;

  try {
    while (true) {
      let state = await assertScanActive(runId);
      if (state.nextIndex >= state.dates.length) {
        await saveScanState({
          ...state,
          status: "completed",
          retry: null,
          progress: `Completed — ${state.checked} dates checked, ${state.found} with slots.`,
          finishedAt: new Date().toISOString(),
        });
        return;
      }

      const date = state.dates[state.nextIndex];
      state = await saveScanState({
        ...state,
        retry: null,
        progress: `Checking ${date}… (${state.nextIndex + 1}/${state.total})`,
      });

      const result = await checkDateWithRetries(runId, date, state.vacId);
      state = await assertScanActive(runId);
      const results = [...state.results, result];
      const nextIndex = state.nextIndex + 1;
      state = await saveScanState({
        ...state,
        results,
        nextIndex,
        checked: results.length,
        found: results.filter((item) => item.available).length,
        retry: null,
        progress: `Checked ${nextIndex}/${state.total} dates.`,
      });

      if (nextIndex < state.total) {
        const delayMs = REQUEST_DELAY_MS + Math.floor(Math.random() * REQUEST_JITTER_MS);
        await waitWithPersistence(runId, delayMs);
      }
    }
  } catch (error) {
    if (error instanceof ScanCancelledError) {
      await finishCancelledScan(runId);
      return;
    }

    const state = await getScanState();
    if (!state || state.runId !== runId) return;
    await saveScanState({
      ...state,
      status: "error",
      retry: null,
      progress: "Scan stopped because of an unexpected error.",
      error: error instanceof Error ? error.message : String(error),
      finishedAt: new Date().toISOString(),
    });
  }
}

function ensureScanRunning() {
  if (activeScanPromise) return activeScanPromise;
  activeScanPromise = runPersistedScan().finally(() => {
    activeScanPromise = null;
  });
  return activeScanPromise;
}

async function startScan(message) {
  const dates = Array.isArray(message.dates) ? message.dates.filter(isValidDate) : [];
  const vacId = Number(message.vacId);
  if (!dates.length || dates.length > 31) throw new Error("Choose between 1 and 31 valid dates.");
  if (!Number.isInteger(vacId) || vacId <= 0) throw new Error("Enter a valid positive VAC ID.");

  const existing = await getScanState();
  if (existing?.status === "running") {
    ensureScanRunning();
    return { ok: false, error: "A scan is already running.", state: existing };
  }

  const now = new Date().toISOString();
  const state = await saveScanState({
    runId: createRunId(),
    status: "running",
    mode: message.mode === "date" ? "date" : "month",
    dates,
    vacId,
    selection: message.selection || null,
    results: [],
    nextIndex: 0,
    checked: 0,
    total: dates.length,
    found: 0,
    retry: null,
    cancelRequested: false,
    progress: `Starting scan for ${dates.length} ${dates.length === 1 ? "date" : "dates"}…`,
    startedAt: now,
    updatedAt: now,
  });
  if (activeScanPromise) await activeScanPromise;
  ensureScanRunning();
  return { ok: true, state };
}

async function cancelScan() {
  const state = await getScanState();
  if (!state || state.status !== "running") return { ok: false, state };
  const nextState = await saveScanState({
    ...state,
    cancelRequested: true,
    progress: "Cancelling…",
  });
  ensureScanRunning();
  return { ok: true, state: nextState };
}

chrome.runtime.onMessage.addListener((message, _sender, sendResponse) => {
  let task;
  if (message?.type === "CHECK_SLOT") task = checkSlot(message.date, message.vacId);
  else if (message?.type === "START_SCAN") task = startScan(message);
  else if (message?.type === "CANCEL_SCAN") task = cancelScan();
  else if (message?.type === "GET_SCAN_STATE") {
    ensureScanRunning();
    task = getScanState().then((state) => ({ state }));
  } else return false;

  Promise.resolve(task)
    .then(sendResponse)
    .catch((error) => sendResponse({ ok: false, error: error.message || String(error) }));
  return true;
});

chrome.alarms.onAlarm.addListener((alarm) => {
  if (alarm.name === WATCHDOG_ALARM) ensureScanRunning();
});

chrome.runtime.onStartup.addListener(() => {
  ensureScanRunning();
});
